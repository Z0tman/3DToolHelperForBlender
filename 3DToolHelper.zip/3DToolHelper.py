bl_info = {
    "name": "3D Tool Helper",
    "author": "Logmegiga",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "",
    "description": "Helper Geometry to make simpler to set position for lighting or complex scenes composition",
    "warning": "",
    "doc_url": "",
    "category": "Helper Function",
}

import bpy
import math
from math import *
from mathutils import Vector

from bpy.types import(
    Panel,
    Operator,
    PropertyGroup,
    )
    
from bpy.props import(
    StringProperty,
    PointerProperty,
    FloatProperty,
    IntProperty
    )
    
class HelperPanel(Panel):
    bl_label = "Helper Generator Panel"
    bl_idname = "OBJECT_PT_helper"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3D Helper Tool"

    def draw(self, context):
        layout = self.layout
        
        scene = context.scene.helper_properties
        col = layout.column()
        col.prop(scene,"moveFactor")
        col = layout.column()
        col.operator("johnson.helper")

class HelperGenerator(Operator):
    bl_idname = "johnson.helper"
    bl_label = "GENERATE"
    bl_description = "spawn helper geometry for scene setting"

    def execute(self, context):
        #main(context)
        scene = context.scene.helper_properties
        amount = scene.moveFactor
        
        #PROCESS THE HELPER GENERATION
        spawnJohnsonOctaedron("johnson",amount/3,Vector((bpy.context.scene.cursor.location.x,bpy.context.scene.cursor.location.y,bpy.context.scene.cursor.location.z)))
        #set object reference
        helperMesh = bpy.context.scene.objects['johnson']
        #set object selection
        helperMesh.select_set(state=True)
        bpy.context.view_layer.objects.active = helperMesh

        decompose(amount)
        return {'FINISHED'}
    
class helper_Properties(PropertyGroup):
    moveFactor : FloatProperty(
        name = "amount",
        description = "the distance from center to get all position for scene setting",
        default = 100
    )

classes = (
    HelperPanel,
    HelperGenerator,
    helper_Properties
    )

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.helper_properties = PointerProperty(type=helper_Properties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.helper_properties

if __name__ == "__main__":
    register()


###################################################################################################################################################################
###################################################################__GEOMETRY CODE__###############################################################################
###################################################################################################################################################################

#TODO : SAVE CURSOR 3D POSITION TO PREVENT MULTIPLE GENERATION AT THE SAME POINT
#TODO : MERGE ALL GEOMETRIES AND GIVE IT A SPECIFIC NAME
#3D CURSOR POSITION : bpy.context.scene.cursor.location

#initialization
size = 10
vertices = [
    (size/2,size/2,0),                                  #0
    (size/2,-size/2,0),                                 #1
    (-size/2,-size/2,0),                                #2
    (-size/2,size/2,0),                                 #3
    
    (0.5*size + size*math.sin(math.pi/4),0.5*size,-size*math.cos(math.pi/4)),                          #4
    (0.5*size + size*math.sin(math.pi/4),-0.5*size,-size*math.cos(math.pi/4)),                         #5
    
    (0.5*size,-0.5*size - size*math.sin(math.pi/4),-size*math.cos(math.pi/4)),                         #6
    (-0.5*size,-0.5*size - size*math.sin(math.pi/4),-size*math.cos(math.pi/4)),                        #7
    
    (-0.5*size - size*math.sin(math.pi/4),-0.5*size,-size*math.cos(math.pi/4)),                        #8
    (-0.5*size - size*math.sin(math.pi/4),0.5*size,-size*math.cos(math.pi/4)),                         #9
    
    (-0.5*size,0.5*size + size*math.sin(math.pi/4),-size*math.cos(math.pi/4)),                         #10
    (0.5*size,0.5*size + size*math.sin(math.pi/4),-size*math.cos(math.pi/4)),                          #11 
    
    
    (0.5*size + size*math.sin(math.pi/4),0.5*size,-size*math.cos(math.pi/4) - size),                  #12
    (0.5*size + size*math.sin(math.pi/4),-0.5*size,-size*math.cos(math.pi/4) - size),                 #13
    
    (0.5*size,-0.5*size - size*math.sin(math.pi/4),-size*math.cos(math.pi/4) - size),                 #14
    (-0.5*size,-0.5*size - size*math.sin(math.pi/4),-size*math.cos(math.pi/4) - size),                #15
    
    (-0.5*size - size*math.sin(math.pi/4),-0.5*size,-size*math.cos(math.pi/4) - size),                #16
    (-0.5*size - size*math.sin(math.pi/4),0.5*size,-size*math.cos(math.pi/4) - size),                 #17
    
    (-0.5*size,0.5*size + size*math.sin(math.pi/4),-size*math.cos(math.pi/4) - size),                 #18
    (0.5*size,0.5*size + size*math.sin(math.pi/4),-size*math.cos(math.pi/4) - size),                  #19
    
    
    (size/2,size/2,-2*size*math.cos(math.pi/4) - size),                                                 #20
    (size/2,-size/2,-2*size*math.cos(math.pi/4) - size),                                                #21
    (-size/2,-size/2,-2*size*math.cos(math.pi/4) - size),                                               #22
    (-size/2,size/2,-2*size*math.cos(math.pi/4) - size),                                                #23 
]

#base shape function
def spawnJohnsonOctaedron(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
        origin + Vector((length/2,length/2,0)),                                  #0
        origin + Vector((length/2,-length/2,0)),                                 #1
        origin + Vector((-length/2,-length/2,0)),                                #2
        origin + Vector((-length/2,length/2,0)),                                 #3
        
        origin + Vector((0.5*length + length*math.sin(math.pi/4),0.5*length,-length*math.cos(math.pi/4))),                          #4
        origin + Vector((0.5*length + length*math.sin(math.pi/4),-0.5*length,-length*math.cos(math.pi/4))),                         #5
        
        origin + Vector((0.5*length,-0.5*length - length*math.sin(math.pi/4),-length*math.cos(math.pi/4))),                         #6
        origin + Vector((-0.5*length,-0.5*length - length*math.sin(math.pi/4),-length*math.cos(math.pi/4))),                        #7
        
        origin + Vector((-0.5*length - length*math.sin(math.pi/4),-0.5*length,-length*math.cos(math.pi/4))),                        #8
        origin + Vector((-0.5*length - length*math.sin(math.pi/4),0.5*length,-length*math.cos(math.pi/4))),                         #9
        
        origin + Vector((-0.5*length,0.5*length + length*math.sin(math.pi/4),-length*math.cos(math.pi/4))),                         #10
        origin + Vector((0.5*length,0.5*length + length*math.sin(math.pi/4),-length*math.cos(math.pi/4))),                          #11 
        
        
        origin + Vector((0.5*length + length*math.sin(math.pi/4),0.5*length,-length*math.cos(math.pi/4) - length)),                  #12
        origin + Vector((0.5*length + length*math.sin(math.pi/4),-0.5*length,-length*math.cos(math.pi/4) - length)),                 #13
        
        origin + Vector((0.5*length,-0.5*length - length*math.sin(math.pi/4),-length*math.cos(math.pi/4) - length)),                 #14
        origin + Vector((-0.5*length,-0.5*length - length*math.sin(math.pi/4),-length*math.cos(math.pi/4) - length)),                #15
        
        origin + Vector((-0.5*length - length*math.sin(math.pi/4),-0.5*length,-length*math.cos(math.pi/4) - length)),                #16
        origin + Vector((-0.5*length - length*math.sin(math.pi/4),0.5*length,-length*math.cos(math.pi/4) - length)),                 #17
        
        origin + Vector((-0.5*length,0.5*length + length*math.sin(math.pi/4),-length*math.cos(math.pi/4) - length)),                 #18
        origin + Vector((0.5*length,0.5*length + length*math.sin(math.pi/4),-length*math.cos(math.pi/4) - length)),                  #19
        
        
        origin + Vector((length/2,length/2,-2*length*math.cos(math.pi/4) - length)),                                                 #20
        origin + Vector((length/2,-length/2,-2*length*math.cos(math.pi/4) - length)),                                                #21
        origin + Vector((-length/2,-length/2,-2*length*math.cos(math.pi/4) - length)),                                               #22
        origin + Vector((-length/2,length/2,-2*length*math.cos(math.pi/4) - length)),                                                #23 
        ]
    edges=[]
    faces=[
        (0,1,2,3),
        (0,4,5,1),
        (1,6,7,2),
        (2,8,9,3),
        (3,10,11,0),
        
        (0,11,4),
        (1,5,6),
        (2,7,8),
        (3,9,10),
        
        (4,12,13,5),
        (5,13,14,6),
        (6,14,15,7),
        (7,15,16,8),
        (8,16,17,9),
        (9,17,18,10),
        (10,18,19,11),
        (11,19,12,4),
        
        (20,19,12),
        (21,13,14),
        (22,15,16),
        (23,17,18),
        
        (20,12,13,21),
        (21,14,15,22),
        (22,16,17,23),
        (23,18,19,20),
        (20,21,22,23)
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

def duplicateAndmove(obj, suffix, translate):
    # duplicate object
    obj2 = bpy.data.objects.new(obj.name + suffix, obj.data)

    # move object
    obj2.location += translate

    # link object to active collection
    bpy.context.collection.objects.link(obj2)

    return obj2

dataSquare = [(0,0,0),(0,0,0),(0,0,0),(0,0,0)] 
def spawnSquare(name, dataSquare, origin=Vector((0,0,0))):
    #components
    coords = [
       origin + Vector((dataSquare[0][0],dataSquare[0][1],dataSquare[0][2])),
       origin + Vector((dataSquare[1][0],dataSquare[1][1],dataSquare[1][2])),
       origin + Vector((dataSquare[2][0],dataSquare[2][1],dataSquare[2][2])),
       origin + Vector((dataSquare[3][0],dataSquare[3][1],dataSquare[3][2])),

        ]
    edges=[]
    faces=[
        (0,1,2,3),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

dataTriangle = [(0,0,0),(0,0,0),(0,0,0)] 
def spawnTriangle(name, dataTriangle, origin=Vector((0,0,0))):
    #components
    coords = [
       origin + Vector((dataTriangle[0][0],dataTriangle[0][1],dataTriangle[0][2])),
       origin + Vector((dataTriangle[1][0],dataTriangle[1][1],dataTriangle[1][2])),
       origin + Vector((dataTriangle[2][0],dataTriangle[2][1],dataTriangle[2][2])),

        ]
    edges=[]
    faces=[
        (0,1,2),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj 

def getSquareLength(pointA,pointB):
    return math.sqrt(math.pow(pointB[0] - pointA[0],2) + math.pow(pointB[1] - pointA[1],2) + math.pow(pointB[2] - pointA[2],2))

def getTriangleLength(pointA,pointB):
    return math.sqrt(math.pow(pointB[0] - pointA[0],2) + math.pow(pointB[1] - pointA[1],2) + math.pow(pointB[2] - pointA[2],2))

def decompose(moveFactor):
    decomposeList = []
        
    #DECOMPOSITION DE LA COUPOLE SUPERIEURE
        #DECOMPOSITION DES FACES CARREES
    dataSquare[0] = vertices[0]
    dataSquare[1] = vertices[1]
    dataSquare[2] = vertices[2]
    dataSquare[3] = vertices[3]
    spawnSquare("topCenterFace",dataSquare)
    decomposeList.append("topCenterFace")    
    topCenterFace = bpy.context.scene.objects['topCenterFace']

    dataSquare[0] = vertices[0]
    dataSquare[1] = vertices[4]
    dataSquare[2] = vertices[5]
    dataSquare[3] = vertices[1]
    topRightFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("topRightFace",dataSquare)
    decomposeList.append("topRightFace")
    topRightFace = bpy.context.scene.objects['topRightFace']

    dataSquare[0] = vertices[1]
    dataSquare[1] = vertices[6]
    dataSquare[2] = vertices[7]
    dataSquare[3] = vertices[2]
    spawnSquare("topBackFace",dataSquare)
    topBackFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    decomposeList.append("topBackFace")
    topBackFace = bpy.context.scene.objects['topBackFace']

    dataSquare[0] = vertices[2]
    dataSquare[1] = vertices[8]
    dataSquare[2] = vertices[9]
    dataSquare[3] = vertices[3]
    topLeftFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("topLeftFace",dataSquare)
    decomposeList.append("topLeftFace")
    topLeftFace = bpy.context.scene.objects['topLeftFace']

    dataSquare[0] = vertices[3]
    dataSquare[1] = vertices[10]
    dataSquare[2] = vertices[11]
    dataSquare[3] = vertices[0]
    spawnSquare("topFrontFace",dataSquare)
    topFrontFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    decomposeList.append("topFrontFace")
    topFrontFace = bpy.context.scene.objects['topFrontFace']
        #DECOMPOSITION DES FACES TRIANGULAIRES
    dataTriangle[0] = vertices[0]      
    dataTriangle[1] = vertices[11]      
    dataTriangle[2] = vertices[4]
    topFrontRightFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("topFrontRightFace",dataTriangle)
    decomposeList.append("topFrontRightFace")
    topFrontRightFace = bpy.context.scene.objects['topFrontRightFace']

    dataTriangle[0] = vertices[1]      
    dataTriangle[1] = vertices[5]      
    dataTriangle[2] = vertices[6]
    topBackRightFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("topBackRightFace",dataTriangle)
    decomposeList.append("topBackRightFace")
    topBackRightFace = bpy.context.scene.objects['topBackRightFace']

    dataTriangle[0] = vertices[2]      
    dataTriangle[1] = vertices[7]      
    dataTriangle[2] = vertices[8]
    topBackLeftFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("topBackLeftFace",dataTriangle)
    decomposeList.append("topBackLeftFace")
    topBackLeftFace = bpy.context.scene.objects['topBackLeftFace']

    dataTriangle[0] = vertices[3]      
    dataTriangle[1] = vertices[9]      
    dataTriangle[2] = vertices[10]
    topFrontLeftFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("topFrontLeftFace",dataTriangle)
    decomposeList.append("topFrontLeftFace")
    topFrontLeftFace = bpy.context.scene.objects['topFrontLeftFace']

    #DECOMPOSITION DE LA CEINTURE OCTAEDRIQUE
    dataSquare[0] = vertices[4]
    dataSquare[1] = vertices[12]
    dataSquare[2] = vertices[13]
    dataSquare[3] = vertices[5]
    middleRightFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleRightFace",dataSquare)
    decomposeList.append("middleRightFace")
    middleRightFace = bpy.context.scene.objects['middleRightFace']

    dataSquare[0] = vertices[5]
    dataSquare[1] = vertices[13]
    dataSquare[2] = vertices[14]
    dataSquare[3] = vertices[6]
    spawnSquare("middleBackRightFace",dataSquare)
    middleBackRightFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    decomposeList.append("middleBackRightFace")
    middleBackRightFace = bpy.context.scene.objects['middleBackRightFace']

    dataSquare[0] = vertices[6]
    dataSquare[1] = vertices[14]
    dataSquare[2] = vertices[15]
    dataSquare[3] = vertices[7]
    middleBackFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleBackFace",dataSquare)
    decomposeList.append("middleBackFace")
    middleBackFace = bpy.context.scene.objects['middleBackFace']

    dataSquare[0] = vertices[7]
    dataSquare[1] = vertices[15]
    dataSquare[2] = vertices[16]
    dataSquare[3] = vertices[8]
    middleBackLeftFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleBackLeftFace",dataSquare)
    decomposeList.append("middleBackLeftFace")
    middleBackLeftFace = bpy.context.scene.objects['middleBackLeftFace']

    dataSquare[0] = vertices[8]
    dataSquare[1] = vertices[16]
    dataSquare[2] = vertices[17]
    dataSquare[3] = vertices[9]
    middleLeftFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleLeftFace",dataSquare)
    decomposeList.append("middleLeftFace")
    middleLeftFace = bpy.context.scene.objects['middleLeftFace']

    dataSquare[0] = vertices[9]
    dataSquare[1] = vertices[17]
    dataSquare[2] = vertices[18]
    dataSquare[3] = vertices[10]
    middleFrontLeftFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleFrontLeftFace",dataSquare)
    decomposeList.append("middleFrontLeftFace")
    middleFrontLeftFace = bpy.context.scene.objects['middleFrontLeftFace']

    dataSquare[0] = vertices[10]
    dataSquare[1] = vertices[18]
    dataSquare[2] = vertices[19]
    dataSquare[3] = vertices[11]
    middleFrontFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleFrontFace",dataSquare)
    decomposeList.append("middleFrontFace")
    middleFrontFace = bpy.context.scene.objects['middleFrontFace']

    dataSquare[0] = vertices[11]
    dataSquare[1] = vertices[19]
    dataSquare[2] = vertices[12]
    dataSquare[3] = vertices[4]
    middleFrontRightFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("middleFrontRightFace",dataSquare)
    decomposeList.append("middleFrontRightFace")
    middleFrontRightFace = bpy.context.scene.objects['middleFrontRightFace']

    #DECOMPOSITION DE LA COUPOLE INFERIEURE
        #DECOMPOSITION DES FACES CARREES
    dataSquare[0] = vertices[20]
    dataSquare[1] = vertices[21]
    dataSquare[2] = vertices[22]
    dataSquare[3] = vertices[23]
    bottomCenterFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("bottomCenterFace",dataSquare)
    decomposeList.append("bottomCenterFace")
    bottomCenterFace = bpy.context.scene.objects['bottomCenterFace']

    dataSquare[0] = vertices[20]
    dataSquare[1] = vertices[12]
    dataSquare[2] = vertices[13]
    dataSquare[3] = vertices[21]
    bottomRightFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("bottomRightFace",dataSquare)
    decomposeList.append("bottomRightFace")
    bottomRightFace = bpy.context.scene.objects['bottomRightFace']

    dataSquare[0] = vertices[21]
    dataSquare[1] = vertices[14]
    dataSquare[2] = vertices[15]
    dataSquare[3] = vertices[22]
    bottomBackFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("bottomBackFace",dataSquare)
    decomposeList.append("bottomBackFace")
    bottomBackFace = bpy.context.scene.objects['bottomBackFace']

    dataSquare[0] = vertices[22]
    dataSquare[1] = vertices[16]
    dataSquare[2] = vertices[17]
    dataSquare[3] = vertices[23]
    bottomLeftFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("bottomLeftFace",dataSquare)
    decomposeList.append("bottomLeftFace")
    bottomLeftFace = bpy.context.scene.objects['bottomLeftFace']

    dataSquare[0] = vertices[23]
    dataSquare[1] = vertices[18]
    dataSquare[2] = vertices[19]
    dataSquare[3] = vertices[20]
    bottomFrontFaceLength = getSquareLength(dataSquare[0],dataSquare[1])
    spawnSquare("bottomFrontFace",dataSquare)
    decomposeList.append("bottomFrontFace")
    bottomFrontFace = bpy.context.scene.objects['bottomFrontFace']

      #DECOMPOSITION DES FACES TRIANGULAIRES
      
    dataTriangle[0] = vertices[20]      
    dataTriangle[1] = vertices[19]      
    dataTriangle[2] = vertices[12]
    bottomFrontRightFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("bottomFrontRightFace",dataTriangle)
    decomposeList.append("bottomFrontRightFace")
    bottomFrontRightFace = bpy.context.scene.objects['bottomFrontRightFace']

    dataTriangle[0] = vertices[21]      
    dataTriangle[1] = vertices[13]      
    dataTriangle[2] = vertices[14]
    bottomBackRightFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("bottomBackRightFace",dataTriangle)
    decomposeList.append("bottomBackRightFace")
    bottomBackRightFace = bpy.context.scene.objects['bottomBackRightFace']

    dataTriangle[0] = vertices[22]      
    dataTriangle[1] = vertices[15]      
    dataTriangle[2] = vertices[16]
    bottomBackLeftFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("bottomBackLeftFace",dataTriangle)
    decomposeList.append("bottomBackLeftFace")
    bottomBackLeftFace = bpy.context.scene.objects['bottomBackLeftFace']

    dataTriangle[0] = vertices[23]      
    dataTriangle[1] = vertices[17]      
    dataTriangle[2] = vertices[18]
    bottomFrontLeftFaceLength = getTriangleLength(dataTriangle[0],dataTriangle[1])
    spawnTriangle("bottomFrontLeftFace",dataTriangle)
    decomposeList.append("bottomFrontLeftFace")
    bottomFrontLeftFace = bpy.context.scene.objects['bottomFrontLeftFace']
    
    #SCATTER FACES OF JOHNSON HELPER SOLID
    topCenterFace.location.x += bpy.context.scene.cursor.location.x
    topCenterFace.location.y += bpy.context.scene.cursor.location.y
    topCenterFace.location.z += bpy.context.scene.cursor.location.z + moveFactor * size*math.cos(math.pi/4)
    
    topRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4) - topRightFaceLength+math.sin(math.pi/4)
    topRightFace.location.y += bpy.context.scene.cursor.location.y
    topRightFace.location.z += bpy.context.scene.cursor.location.z + (moveFactor*0.5*size*math.cos(math.pi/4)) + topRightFaceLength*math.cos(math.pi/4)
    
    
    topBackFace.location.x += bpy.context.scene.cursor.location.x
    topBackFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4) + topBackFaceLength+math.sin(math.pi/4)
    topBackFace.location.z += bpy.context.scene.cursor.location.z + (moveFactor*0.5*size*math.cos(math.pi/4)) + topBackFaceLength*math.cos(math.pi/4)
    
    topLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4) + topLeftFaceLength+math.sin(math.pi/4)
    topLeftFace.location.y += bpy.context.scene.cursor.location.y
    topLeftFace.location.z += bpy.context.scene.cursor.location.z + (moveFactor*0.5*size*math.cos(math.pi/4)) + topLeftFaceLength*math.cos(math.pi/4)
    
    topFrontFace.location.x += bpy.context.scene.cursor.location.x
    topFrontFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4) - topFrontFaceLength+math.sin(math.pi/4)
    topFrontFace.location.z += bpy.context.scene.cursor.location.z + (moveFactor*0.5*size*math.cos(math.pi/4))  + topFrontFaceLength*math.cos(math.pi/4)
    
        #SCATTER TOP TRIANGLE FACES
    
    topFrontRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4) - topFrontRightFaceLength*math.sin(math.pi/4)
    topFrontRightFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4) + topFrontRightFaceLength*math.sin(math.pi/4)
    topFrontRightFace.location.z += bpy.context.scene.cursor.location.z + moveFactor*0.5*size*math.sin(math.pi/4) + topFrontRightFaceLength*math.cos(math.pi/4)
    
    topBackRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4) - topBackRightFaceLength*math.sin(math.pi/4)
    topBackRightFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4) - topBackRightFaceLength*math.sin(math.pi/4)
    topBackRightFace.location.z += bpy.context.scene.cursor.location.z + moveFactor*0.5*size*math.sin(math.pi/4) + topBackRightFaceLength*math.cos(math.pi/4)
    
    topBackLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4) + topBackLeftFaceLength*math.sin(math.pi/4)
    topBackLeftFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4) - topBackLeftFaceLength*math.sin(math.pi/4)
    topBackLeftFace.location.z += bpy.context.scene.cursor.location.z + moveFactor*0.5*size*math.sin(math.pi/4) + topBackLeftFaceLength*math.cos(math.pi/4)
    
    topFrontLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4) + topFrontLeftFaceLength*math.sin(math.pi/4)
    topFrontLeftFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4) + topFrontLeftFaceLength*math.sin(math.pi/4)
    topFrontLeftFace.location.z += bpy.context.scene.cursor.location.z + moveFactor*0.5*size*math.sin(math.pi/4) + topFrontLeftFaceLength*math.cos(math.pi/4)
    
        #SCATTER OCTAEDRON BELT FACES
            
    middleRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*size*math.sin(math.pi/4)
    middleRightFace.location.y += bpy.context.scene.cursor.location.y
    middleRightFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleBackFace.location.x += bpy.context.scene.cursor.location.x
    middleBackFace.location.y += bpy.context.scene.cursor.location.y -moveFactor*size*math.sin(math.pi/4)
    middleBackFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*size*math.sin(math.pi/4)
    middleLeftFace.location.y += bpy.context.scene.cursor.location.y
    middleLeftFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleFrontFace.location.x += bpy.context.scene.cursor.location.x
    middleFrontFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*size*math.sin(math.pi/4)
    middleFrontFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleFrontRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4)
    middleFrontRightFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4)
    middleFrontRightFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    
    middleBackRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4)
    middleBackRightFace.location.y += bpy.context.scene.cursor.location.y -moveFactor*0.5*size*math.sin(math.pi/4)
    middleBackRightFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleBackLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4)
    middleBackLeftFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4)
    middleBackLeftFace.location.z += bpy.context.scene.cursor.location.z + middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
    middleFrontLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4)
    middleFrontLeftFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4)
    middleFrontLeftFace.location.z +=  bpy.context.scene.cursor.location.z +middleFrontFaceLength*math.cos(math.pi/4) + middleFrontFaceLength
    
        #SCATTER BOTTOM COUPOLE
    
    bottomCenterFace.location.x += bpy.context.scene.cursor.location.x
    bottomCenterFace.location.y += bpy.context.scene.cursor.location.y
    bottomCenterFace.location.z += bpy.context.scene.cursor.location.z - moveFactor * size*math.cos(math.pi/4)
    
    bottomRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4) + bottomRightFaceLength+math.sin(math.pi/4)
    bottomRightFace.location.y += bpy.context.scene.cursor.location.y
    bottomRightFace.location.z += bpy.context.scene.cursor.location.z - (moveFactor*0.5*size*math.cos(math.pi/4)) - bottomRightFaceLength*math.cos(math.pi/4)
    
    
    bottomBackFace.location.x += bpy.context.scene.cursor.location.x
    bottomBackFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4) - bottomBackFaceLength+math.sin(math.pi/4)
    bottomBackFace.location.z += bpy.context.scene.cursor.location.z - (moveFactor*0.5*size*math.cos(math.pi/4)) + bottomBackFaceLength*math.cos(math.pi/4)
    
    bottomLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4) - bottomLeftFaceLength+math.sin(math.pi/4)
    bottomLeftFace.location.y += bpy.context.scene.cursor.location.y
    bottomLeftFace.location.z += bpy.context.scene.cursor.location.z - (moveFactor*0.5*size*math.cos(math.pi/4)) + bottomLeftFaceLength*math.cos(math.pi/4)
    
    bottomFrontFace.location.x += bpy.context.scene.cursor.location.x
    bottomFrontFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4) + bottomFrontFaceLength+math.sin(math.pi/4)
    bottomFrontFace.location.z += bpy.context.scene.cursor.location.z - (moveFactor*0.5*size*math.cos(math.pi/4)) + bottomFrontFaceLength*math.cos(math.pi/4)
    
        #SCATTER BOTTOM TRIANGLE FACES
    
    bottomFrontRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4)
    bottomFrontRightFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4)
    bottomFrontRightFace.location.z += bpy.context.scene.cursor.location.z - moveFactor*0.5*size*math.sin(math.pi/4)
    
    bottomBackRightFace.location.x += bpy.context.scene.cursor.location.x + moveFactor*0.5*size*math.sin(math.pi/4)
    bottomBackRightFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4)
    bottomBackRightFace.location.z += bpy.context.scene.cursor.location.z - moveFactor*0.5*size*math.sin(math.pi/4)
    
    bottomBackLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4)
    bottomBackLeftFace.location.y += bpy.context.scene.cursor.location.y - moveFactor*0.5*size*math.sin(math.pi/4)
    bottomBackLeftFace.location.z += bpy.context.scene.cursor.location.z - moveFactor*0.5*size*math.sin(math.pi/4)
    
    bottomFrontLeftFace.location.x += bpy.context.scene.cursor.location.x - moveFactor*0.5*size*math.sin(math.pi/4)
    bottomFrontLeftFace.location.y += bpy.context.scene.cursor.location.y + moveFactor*0.5*size*math.sin(math.pi/4)
    bottomFrontLeftFace.location.z += bpy.context.scene.cursor.location.z - moveFactor*0.5*size*math.sin(math.pi/4)
    
    #RESIZE FACE OVER DISTANCE
    topCenterFace.scale *= (moveFactor/10)+(moveFactor/8)    
    topRightFace.scale *= (moveFactor/10)+(moveFactor/8)  
    topBackFace.scale *= (moveFactor/10)+(moveFactor/8)  
    topLeftFace.scale *= (moveFactor/10)+(moveFactor/8)  
    topFrontFace.scale *= (moveFactor/10)+(moveFactor/8)   
    
    topFrontRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    topBackRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    topBackLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    topFrontLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
            
    middleRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleBackFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleFrontFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleFrontRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleBackRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleBackLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    middleFrontLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    
    bottomCenterFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomBackFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomFrontFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomFrontRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomBackRightFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomBackLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
    bottomFrontLeftFace.scale *= (moveFactor/10)+(moveFactor/8)
                            
    
    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in (decomposeList[0],decomposeList[1],decomposeList[2],decomposeList[3],decomposeList[4],decomposeList[5],decomposeList[6],decomposeList[7],decomposeList[8],decomposeList[9],decomposeList[10],decomposeList[11],decomposeList[12],decomposeList[13],decomposeList[14],decomposeList[15],decomposeList[16],decomposeList[17],decomposeList[18],decomposeList[19],decomposeList[20],decomposeList[21],decomposeList[22],decomposeList[23],decomposeList[24],decomposeList[25]):
            o.select_set(True)
            
    helperMesh = bpy.context.scene.objects['johnson']        
    helperMesh.select_set(state=True)
    bpy.context.view_layer.objects.active = helperMesh
    bpy.ops.object.join()
    
    bpy.data.objects["johnson"].name = "helperSet"
    